<?php
include 'includes/connect.php';

	$id=$_GET['product'];

	$pname=$_POST['pname'];
	$pdesc=$_POST['pdesc'];
	$price=$_POST['price'];

	$sql="select * from items where productid='$id'";
	$query=$con->query($sql);
	$row=$query->fetch_array();

	$fileinfo=PATHINFO($_FILES["photo"]["name"]);

	if (empty($fileinfo['filename'])){
		$location = $row['photo'];
	}
	else{
		$newFilename=$fileinfo['filename'] ."_". time() . "." . $fileinfo['extension'];
		move_uploaded_file($_FILES["photo"]["tmp_name"],"upload/" . $newFilename);
		$location="upload/" . $newFilename;
	}

	$sql="update items set productname='$pname', productdesc='$pdesc', price='$price', photo='$location' where productid='$id'";
	$con->query($sql);

	header('location:product_maint.php');
?>