<?php
$user_id=$_SESSION['user_id'];
$sql = mysqli_query($con, "SELECT round(SUM(grand_total),2) grand_total FROM orders where customer_id = $user_id and deleted = 0");
while($row1 = mysqli_fetch_array($sql)){
$balance = $row1['grand_total'];
}
?>