<?php
include '../includes/connect.php';
$success=false;

$userid = $_POST['userid'];
$password = $_POST['password'];

$result = mysqli_query($con, "SELECT * FROM users WHERE userid='$userid' AND password='$password' AND role='Partner' AND not deleted;");
while($row = mysqli_fetch_array($result))
{
	$success = true;
	$user_id = $row['id'];
	$fname = $row['fname'];
	$lname = $row['lname'];
	$role= $row['role'];
	$photo= $row['photo'];
}
if($success == true)
{	
	session_start();
	$_SESSION['admin_sid']=session_id();
	$_SESSION['user_id'] = $user_id;
	$_SESSION['role'] = $role;
	$_SESSION['fname'] = $fname;
	$_SESSION['lname'] = $lname;
	$_SESSION['photo'] = $photo;

	header("location: ../product_maint.php");
}
else
{
	$result = mysqli_query($con, "SELECT * FROM users WHERE userid='$userid' AND password='$password' AND role='Consumer' AND not deleted;");
	while($row = mysqli_fetch_array($result))
	{
	$success = true;
	$user_id = $row['id'];
	$fname = $row['fname'];
	$lname = $row['lname'];
	$role= $row['role'];
	$photo= $row['photo'];
	}
	if($success == true)
	{
		session_start();
		$_SESSION['customer_sid']=session_id();
		$_SESSION['user_id'] = $user_id;
		$_SESSION['role'] = $role;
		$_SESSION['fname'] = $fname;	
		$_SESSION['lname'] = $lname;	
		$_SESSION['photo'] = $photo;
		header("location: ../restaurant_menu.php");
	}
	else
	{
		header("location: ../login.php");
	}
}
?>