<?php
include '../includes/connect.php';
$userid = htmlspecialchars($_POST['userid']);
$fname = htmlspecialchars($_POST['fname']);
$lname = htmlspecialchars($_POST['lname']);
$phone = $_POST['phone'];
$email = htmlspecialchars($_POST['email']);
$password = htmlspecialchars($_POST['password']);

if ($phone < 60) {
	$phone = '60';
}
else
	{
	$phone = '60'.$phone;
}

function number($length) {
    $result = '';

    for($i = 0; $i < $length; $i++) {
        $result .= mt_rand(0, 9);
    }

    return $result;
}

$sql = "INSERT INTO users (role, userid, fname, lname, contact, email, password) VALUES 
('Consumer', '$userid', '$fname', '$lname', $phone, '$email', '$password');";
if($con->query($sql)==true){
$user_id =  $con->insert_id;
}
header("location: ../login.php");
?>