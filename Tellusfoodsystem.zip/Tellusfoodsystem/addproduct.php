<?php
include 'includes/connect.php';
$user_id = $_SESSION['user_id'];

	$pname=$_POST['pname'];
	$pdesc=$_POST['pdesc'];
	$price=$_POST['price'];
	
	$fileinfo=PATHINFO($_FILES["photo"]["name"]);

	if(empty($fileinfo['filename'])){
		$location="";
	}
	else{
	$newFilename=$fileinfo['filename'] ."_". time() . "." . $fileinfo['extension'];
	move_uploaded_file($_FILES["photo"]["tmp_name"],"upload/" . $newFilename);
	$location="upload/" . $newFilename;
	}
	
	$sql="insert into items (restaurant_id, productname, productdesc, price, photo) values ('$user_id', '$pname', '$pdesc', '$price', '$location')";
	$con->query($sql);

	header('location:product_maint.php');

?>